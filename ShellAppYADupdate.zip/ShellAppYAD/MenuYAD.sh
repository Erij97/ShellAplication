function MenuYAD {

	yad --title "SHELL APPLICATION" \
	--image /home/Erij/ShellAplication/icons8-hacking-64.png --image-on-top \
	--text="Today is: $(date +"%d %b %Y")" \
	--text-info --back=black --fore=white --margins=70 --width=900 --height=550 --center < menu.txt \
	--buttons-layout=center \
	--button=" One!/home/Erij/ShellAplication/s1.png":1 \
	--button=" Two!/home/Erij/ShellAplication/s2.png":2 \
	--button=" Three!/home/Erij/ShellAplication/s3.png":3 \
	--button=" Four!/home/Erij/ShellAplication/s4.png":4 \
	--button=" Help!/home/Erij/ShellAplication/helpicon.png":5 \
	--button=gtk-quit:0 \


	choice=$?

	if [[ $choice -eq 1 ]]; then
		source simpleUser.sh

	elif [[ $choice -eq 2 ]]; then
		source ModifierMotDePasseUser.sh

	elif [[ $choice -eq 3 ]]; then
		source Decrypter.sh

	elif [[ $choice -eq 5 ]]; then
		yad --title="HELP" \
		--text-info --back=black --fore=white --margins=70 --width=900 --height=550 --center < help.txt
		#source help.sh

	fi
}


#user=`$(id -u -n)`
#user=`grep $2 /etc/passwd | cut -d: -f3`

if [[ $1 == "" ]]; then
	MenuYAD

elif [[ $1 == "-l" ]]; then
    source simpleUser.sh $1

elif [[ $1 == "-p" ]]; then
   source ModifierMotDePasseUser.sh

elif [[ $1 == "-decrypt" ]]; then
    source Decrypter.sh

#elif [[ $1 == "-s" ]]; then
#    source 

elif [[ $1 == "-help" ]]; then
	source help.sh

fi

