function GestionUsers {

	yad --window-icon="/home/Erij/FinalMenu/icons8-hacking-64.png" \
	--title "Gestion des utilisateurs" \
	--image /home/Erij/FinalMenu/users.png --image-on-top \
	--text-info --back=black --fore=white --margins=70 --width=800 --height=300 --center < gestionUsers.txt \
	--buttons-layout=center \
	--button=" One!/home/Erij/FinalMenu/s1.png":1 \
	--button=" Two!/home/Erij/FinalMenu/s2.png":2 \
	--button="Return!/home/Erij/FinalMenu/return.png":3

	choice=$?

	if [[ $choice -eq 1 ]]; then
		source simpleUser.sh
		MenuGlobal

	elif [[ $choice -eq 2 ]]; then
		source ModifierMotDePasseUser.sh
		MenuGlobal
	
	elif [[ $choice -eq 3 ]]; then
		MenuGlobal
	fi
}

function Decryptage {
	yad --window-icon="/home/Erij/FinalMenu/icons8-hacking-64.png" \
	--image /home/Erij/FinalMenu/crypting.png --image-on-top \
	--title "Decryptage" \
	--text-info --back=black --fore=white --margins=70 --width=800 --height=300 --center < decryptage.txt \
	--buttons-layout=center \
	--button=" One!/home/Erij/FinalMenu/s1.png":1 \
	--button=" Two!/home/Erij/FinalMenu/s2.png":2 \
	--button="Return!/home/Erij/FinalMenu/return.png":3

	choice=$?

	if [[ $choice -eq 1 ]]; then
		source Decrypter.sh
		MenuGlobal

	elif [[ $choice -eq 1 ]]; then
		echo "ugh"

	elif [[ $choice -eq 3 ]]; then
		MenuGlobal
	fi
}

function GestionReseau {
	yad --window-icon="/home/Erij/FinalMenu/icons8-hacking-64.png" \
	--image /home/Erij/FinalMenu/network.png --image-on-top \
	--title "Gestion des réseaux" \
	--text-info --back=black --fore=white --margins=70 --width=800 --height=300 --center < network.txt \
	--buttons-layout=center \
	--button=" One!/home/Erij/FinalMenu/s1.png":1 \
	--button=" Two!/home/Erij/FinalMenu/s2.png":2 \
	--button="Return!/home/Erij/FinalMenu/return.png":3

	choice=$?

	if [[ $choice -eq 1 ]]; then
		source checkPing.sh
		MenuGlobal

	elif [[ $choice -eq 2 ]]; then
		echo "ifohze"

	elif [[ $choice -eq 3 ]]; then
		MenuGlobal
	fi

}


function MenuGlobal {
	yad --width="500" --height="500" --title "SHELL APPLICATION" \
	--window-icon="/home/Erij/FinalMenu/icons8-hacking-64.png" \
	--image /home/Erij/FinalMenu/hacker.jpg --width="1024" --height="500" \
	--buttons-layout=center \
	--button="Gestion des utilisateurs!/home/Erij/FinalMenu/users.png":1 \
	--button="Decryptage!/home/Erij/FinalMenu/crypting.png":2 \
	--button="Gestion du réseau!/home/Erij/FinalMenu/network.png":3 \
	--button="Help!/home/Erij/FinalMenu/help.png":4 \
	--button="EXIST!/home/Erij/FinalMenu/exit.png":5

choix=$?

if [[ $choix -eq 1 ]]; then
	GestionUsers
fi

if [[ $choix -eq 2 ]]; then
	Decryptage
fi

if [[ $choix -eq 3 ]]; then
	GestionReseau
fi

if [[ $choix -eq 4 ]]; then
	yad --title="HELP" \
	--text-info --back=black --fore=white --margins=70 --width=900 --height=550 --center < help.txt
	MenuGlobal
fi

if [[ $choix -eq 5 ]]; then
	exit
fi
}

wmctrl -r 'SHELL APPLICATION'S -e '0,6,0,1000,500'
MenuGlobal


