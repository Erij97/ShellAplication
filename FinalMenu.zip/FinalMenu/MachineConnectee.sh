function MachineConn {
	echo "Voici le ping: "
}